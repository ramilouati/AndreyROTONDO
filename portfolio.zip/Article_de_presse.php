<?php include('./header_footer/header.php'); ?>

<body class="index-page">

<?php include('./header_footer/header_nav.php'); ?>

  <main class="main">


    <section id="hero" class="hero section">

      <h2>Articles de presse</h2>

    </section>

  </main>

<?php include('./header_footer/footer.php'); ?>
</body>

</html>