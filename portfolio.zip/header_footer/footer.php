<footer id="footer" class="footer light-background">

<div class="container">
  <div class="social-links d-flex justify-content-center">
    <a href="https://whatsapp.com/channel/0029Vb54sJOATRSqq9gr9L11" class="whatsapp"><i class="bi bi-whatsapp"></i></a>
    <a href="https://www.facebook.com/share/19Yrm9t6nT/?mibextid=wwXIfr" class="facebook"><i class="bi bi-facebook"></i></a>
    <a href="https://www.instagram.com/andreyrotondo/" class="instagram"><i class="bi bi-instagram"></i></a>
    <a href="mailto:andreyrotondopro@gmail.com?subject=Hello&body=I%20would%20like%20to%20contact%20you" class="instagram">
      <i class="bi bi-envelope-paper-fill"></i>
    </a>      
  </div>
</div>

</footer>

<a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<div id="preloader"></div>

<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

<script src="assets/js/main.js"></script>
